#include "ush.h"

void mx_printerr(const char *s) {
    fprintf(stderr, "%s", s);
}

