#include "ush.h"

void mx_e_nodir_after_split_pwd_cd(char **splited_arg) {
    int count = 0;
    char *env_str = getenv("PWD");
    char *buff_str = mx_strnew(mx_strlen(env_str));
    char *res_str = NULL;
    
    while (splited_arg[count]) {
        count++;
    }
    if (count == 2) {
        buff_str = mx_strcpy(buff_str, env_str);
        printf("%s ", res_str);
        exit(0);
        free(buff_str);
    }
}
